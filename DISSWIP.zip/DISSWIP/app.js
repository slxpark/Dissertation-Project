const navanimate = document.querySelector('#mobile-menu');
const navLinks = document.querySelector('.navbar__menu');

navanimate.addEventListener('click', function() {
  navanimate.classList.toggle('is-active');
  navLinks.classList.toggle('active');
});